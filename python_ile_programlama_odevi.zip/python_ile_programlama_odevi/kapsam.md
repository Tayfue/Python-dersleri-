**Ad Soyad:** Tayfur Tatar  
**Öğrenci No:** 20253006029

# Kapsam (Scope) Tuzakları

Her örnekte önce çıktıyı **tahmin ettim**, sonra kodu çalıştırdım. Örnekler
`tests/test_tuzaklar.py` içinde teste de dönüştürüldü; çıktılar Python 3.13
ile alındı.

Python bir adı ararken sırayla şu kapsamlara bakar (LEGB): **L**ocal (fonksiyonun
içi), **E**nclosing (dıştaki fonksiyon), **G** (modül düzeyi), **B**uilt-in
(`print`, `len` gibi yerleşik adlar).

## Örnek 1 – Yerel değişken, modül düzeyindekini gölgeler

```python
yakit_adi = "modül"

def ornek_1():
    yakit_adi = "yerel"
    print(yakit_adi)

ornek_1()
print(yakit_adi)
```

- **Tahminim:** `yerel`, sonra `modül`
- **Gerçek sonuç:** `yerel`, sonra `modül`
- **Neden:** Fonksiyonun içindeki `yakit_adi = "yerel"` yeni bir **yerel** ad
  oluşturur; modül düzeyindeki aynı adlı değişkene dokunmaz, onu yalnızca
  fonksiyon içinde gölgeler. Fonksiyon bitince yerel ad yok olur, dışarıdaki
  değişken eski değerinde kalır.

## Örnek 2 – İç fonksiyon, dıştaki değişkenin son değerini görür

```python
def ornek_2():
    sayi = 1

    def ic():
        print(sayi)

    sayi = 2
    ic()

ornek_2()
```

- **Tahminim:** `2`
- **Gerçek sonuç:** `2`
- **Neden:** `ic()` içinde `sayi` atanmadığı için ad yerelde bulunamaz ve
  **Enclosing** kapsamda aranır. İç fonksiyon değeri tanımlandığı anda değil,
  **çağrıldığı anda** okur; `ic()` çağrıldığında `sayi` artık `2`'dir. (Closure
  değeri kopyalamaz, değişkenin kendisine bağlanır.)

## Örnek 3 – Döngü kapsam açmaz, liste üreteci açar

```python
def ornek_3():
    for i in range(3):
        pass
    print(i)
    kareler = [j * j for j in range(3)]
    try:
        print(j)
    except NameError as hata:
        print("NameError:", hata)

ornek_3()
```

- **Tahminim:** `2`, sonra `NameError: name 'j' is not defined`
- **Gerçek sonuç:**
  ```
  2
  NameError: name 'j' is not defined
  ```
- **Neden:** `for` döngüsü kendi kapsamını açmaz; `i` fonksiyonun yerel adıdır ve
  döngü bittikten sonra son değeri (`2`) ile yaşamaya devam eder. Liste
  üretecinin (list comprehension) ise **kendi kapsamı** vardır; `j` yalnızca
  üretecin içinde yaşar, dışarıda tanımsızdır.

## UnboundLocalError örneği

```python
depo_miktari = 100

def harca_hatali():
    depo_miktari = depo_miktari - 10
    return depo_miktari

harca_hatali()
```

- **Tahminim:** `UnboundLocalError`. Modül düzeyinde `100` olduğu için `90`
  dönecekmiş gibi görünse de fonksiyon içinde atama yapıldığı için hata bekledim.
- **Gerçek sonuç:**
  ```
  UnboundLocalError: cannot access local variable 'depo_miktari' where it is not associated with a value
  ```
  (Python 3.11'den önceki sürümlerde mesaj: *local variable 'depo_miktari'
  referenced before assignment*.)
- **Neden:** Python bir fonksiyonu çalıştırmadan **önce** derler. Fonksiyonun
  herhangi bir yerinde `depo_miktari = ...` gibi bir **atama** varsa, o ad
  fonksiyonun tamamı boyunca **yerel** sayılır. Sağ taraftaki
  `depo_miktari - 10` ifadesi de bu yerel adı okumaya çalışır, ama yerel ada
  henüz değer atanmamıştır; bu yüzden modül düzeyindeki `100`'e bakılmaz ve
  `UnboundLocalError` oluşur.
- **Doğru çözüm:** Değeri parametre olarak verip sonucu döndürmek:

  ```python
  def harca_duzgun(depo_miktari: int) -> int:
      return depo_miktari - 10

  harca_duzgun(100)   # 90
  ```

  Dıştaki bir **fonksiyonun** değişkenini değiştirmek gerekirse `nonlocal`
  kullanılır (bkz. `hamle_sayaci`). Modül düzeyindeki değişkenleri
  fonksiyonlarda değiştirmekten bu lab'da bilerek kaçınıldı.
